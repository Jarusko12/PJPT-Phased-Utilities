Due to github's file size limits, I will link you to the download for the Unreal Mod Unlocker which you will need.

---------------------
https://illusory.dev/
---------------------